// Gruntfile.js
module.exports = function (grunt) {
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    uglify: {
      options: {
        banner: '/*! <%= pkg.name %> <%= grunt.template.today("yyyy-mm-dd") %> */\n'
      },
      build: {
        src: 'assets/js/<%= pkg.name %>.js',
        dest: 'assets/js/<%= pkg.name %>.min.js'
      }
    },

    // SASS task config
    sass: {
      dist: {
        files: {
            // destination               // source file
            "assets/styles/styles.css" : "assets/styles/styles.scss"
        }
      }
    },
 
    // Watch task config
    watch: {
      gruntfile: {
        files: 'gruntfile.js',
        tasks: ['jshint:gruntfile'],
      },
      js: {
        files: ['**/*.js'],
        options: {
          livereload: true,
        },
      },
      css: {
        files: ['**/*.scss'],
        tasks: ['sass'],
        options: {
          livereload: true,
        },
      },
    }
  });
  
  // Load the plugin that provides the below [eg: "uglify"] task.
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-sass');
  grunt.loadNpmTasks('grunt-contrib-watch');

  //Define Default Grunt Task(s)
  grunt.registerTask('default',['uglify','sass','watch']);
};